
import React, { useEffect, useId } from 'react';

interface AdBannerProps {
  type?: 'leaderboard' | 'rectangle';
  adUnitPath?: string;
}

const AdBanner: React.FC<AdBannerProps> = ({ 
  type = 'leaderboard', 
  adUnitPath = '/1234567/banner_ad' 
}) => {
  const adId = useId().replace(/:/g, '-');
  const slotId = `ad-slot-${adId}`;

  const dimensions: [number, number] = type === 'leaderboard' ? [728, 90] : [300, 250];

  useEffect(() => {
    if (typeof window !== 'undefined' && window.googletag) {
      window.googletag.cmd.push(() => {
        const slot = window.googletag.defineSlot(adUnitPath, dimensions, slotId)
          ?.addService(window.googletag.pubads());
        
        if (slot) {
          window.googletag.display(slotId);
          window.googletag.pubads().refresh([slot]);
        }
      });
    }
  }, [slotId, adUnitPath, dimensions]);

  return (
    <div className={`w-full flex items-center justify-center p-2 bg-slate-900/50 border-y border-slate-800 relative overflow-hidden ${type === 'leaderboard' ? 'h-28' : 'h-[300px]'}`}>
      <div className="absolute top-1 left-2 text-[8px] text-slate-600 font-bold uppercase tracking-widest z-10">Sponsored Mission</div>
      
      {/* Ad Container */}
      <div 
        id={slotId} 
        style={{ minWidth: `${dimensions[0]}px`, minHeight: `${dimensions[1]}px` }}
        className="flex items-center justify-center bg-slate-800/20 rounded border border-slate-700/30"
      >
        <div className="text-center opacity-30 select-none">
          <p className="text-[10px] font-black font-gaming text-slate-500 mb-1">GOOGLE AD MANAGER</p>
          <p className="text-[8px] text-slate-600 uppercase">{dimensions[0]} x {dimensions[1]} SLOT</p>
        </div>
      </div>
    </div>
  );
};

export default AdBanner;
