
/**
 * Service to manage Google Ad Manager (GAM) Interstitial and Rewarded Ads.
 * Designed for low latency by pre-fetching ad slots.
 */

declare global {
  interface Window {
    googletag: any;
  }
}

class AdService {
  private interstitialSlot: any = null;
  private rewardedSlot: any = null;

  constructor() {
    if (typeof window !== 'undefined') {
      window.googletag = window.googletag || { cmd: [] };
      this.initSlots();
    }
  }

  private initSlots() {
    window.googletag.cmd.push(() => {
      // Define Interstitial Slot
      // Replace '/1234567/interstitial' with your actual Ad Unit Path
      this.interstitialSlot = window.googletag.defineOutOfPageSlot(
        '/1234567/interstitial',
        window.googletag.enums.OutOfPageFormat.INTERSTITIAL
      );
      
      if (this.interstitialSlot) {
        this.interstitialSlot.addService(window.googletag.pubads());
      }

      // Define Rewarded Slot
      // Replace '/1234567/rewarded' with your actual Ad Unit Path
      this.rewardedSlot = window.googletag.defineOutOfPageSlot(
        '/1234567/rewarded',
        window.googletag.enums.OutOfPageFormat.REWARDED
      );

      if (this.rewardedSlot) {
        this.rewardedSlot.addService(window.googletag.pubads());
      }
    });
  }

  /**
   * Triggers an Interstitial ad. 
   * Usually called during navigation transitions.
   */
  public showInterstitial() {
    window.googletag.cmd.push(() => {
      window.googletag.display(this.interstitialSlot);
    });
  }

  /**
   * Triggers a Rewarded ad.
   * Takes a callback for when the user completes the reward.
   */
  public showRewarded(onRewardGranted: () => void) {
    window.googletag.cmd.push(() => {
      window.googletag.pubads().addEventListener('rewardedSlotReady', (event: any) => {
        if (confirm('Watch a short video to earn 100 Diamonds?')) {
          event.makeRewardedVisible();
        }
      });

      window.googletag.pubads().addEventListener('rewardedSlotGranted', () => {
        onRewardGranted();
      });

      window.googletag.display(this.rewardedSlot);
    });
  }
}

export const adService = new AdService();
