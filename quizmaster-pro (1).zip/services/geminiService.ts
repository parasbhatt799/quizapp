
import { GoogleGenAI, Type } from "@google/genai";
import { Question, Difficulty } from "../types";

export const generateQuestions = async (category: string, difficulty: Difficulty = 'Easy'): Promise<Question[]> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: `Generate 10 high-quality multiple choice questions for a competitive exam learning quiz about ${category}. 
      The difficulty level MUST be ${difficulty.toUpperCase()}. 
      - Easy: Basic facts and simple concepts.
      - Medium: Conceptual understanding and moderate application.
      - Hard: Complex scenarios, advanced reasoning, and deep technical knowledge.
      Ensure questions are balanced. Format the response as a JSON array of objects.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.OBJECT,
            properties: {
              id: { type: Type.STRING },
              question: { type: Type.STRING },
              options: {
                type: Type.ARRAY,
                items: { type: Type.STRING }
              },
              correctAnswer: { type: Type.STRING }
            },
            required: ["id", "question", "options", "correctAnswer"]
          }
        }
      }
    });

    const text = response.text;
    if (!text) throw new Error("No response from AI");
    return JSON.parse(text);
  } catch (error) {
    console.error("Error generating questions:", error);
    return Array.from({ length: 10 }).map((_, i) => ({
      id: `${i + 1}`,
      question: `[${difficulty}] Sample ${category} question ${i + 1}? (Offline Mode)`,
      options: ["Option A", "Option B", "Option C", "Option D"],
      correctAnswer: "Option A"
    }));
  }
};
